﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.WebSockets;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Xml.Linq;

namespace HikVisionIntegrationService
{
    public partial class Service : ServiceBase
    {
        private ClientWebSocket webSocket;
        private HttpClient httpClient;
        private CancellationTokenSource cancellationTokenSource;
        private Uri wsUri;
        private static readonly string logPath = "C:\\Logs\\hikvision_ws.log";

        public Service()
        {
            InitializeComponent();

            var handler = new HttpClientHandler
            {
                Credentials = new NetworkCredential("admin", "Odesus1977#")
            };
            httpClient = new HttpClient(handler);

            cancellationTokenSource = new CancellationTokenSource();
            _ = InitializeAndConnectAsync(cancellationTokenSource.Token);
        }

        protected override void OnStart(string[] args)
        {
          /*  cancellationTokenSource = new CancellationTokenSource();
            _ = InitializeAndConnectAsync(cancellationTokenSource.Token);*/
        }

        protected override void OnStop()
        {
            cancellationTokenSource?.Cancel();
            webSocket?.Dispose();
        }

/*        private async Task InitializeAndConnectAsync(CancellationToken token)
        {
            try
            {
                string tokenValue = await GetTokenAsync();
                if (string.IsNullOrWhiteSpace(tokenValue))
                {
                    LogMessage("❌ Failed to retrieve token.");
                    return;
                }

                wsUri = new Uri($"ws://172.22.66.71:7681/ISAPI/Event/notification/subscribeEventCap?token={tokenValue}");
                await ConnectWebSocketAsync(token);
            }
            catch (Exception ex)
            {
                LogMessage($"❌ Initialize error: {ex.Message}");
            }
        }*/

        private async Task InitializeAndConnectAsync(CancellationToken token)
        {
            while (!token.IsCancellationRequested)
            {
                try
                {
                    string tokenValue = await GetTokenAsync();
                    if (!string.IsNullOrWhiteSpace(tokenValue))
                    {
                        wsUri = new Uri($"ws://172.22.66.71:7681/ISAPI/Event/notification/subscribeEventCap?token={tokenValue}");
                        await ConnectWebSocketAsync(token);
                        return; // success
                    }
                    else
                    {
                        LogMessage("❌ Token retrieval returned null/empty.");
                    }
                }
                catch (Exception ex)
                {
                    LogMessage($"❌ Token retrieval failed with exception: {ex.Message}");
                }

                LogMessage("🔁 Retrying token retrieval in 10 seconds...");
                await Task.Delay(TimeSpan.FromSeconds(10), token);
            }
        }

        private async Task<string> GetTokenAsync()
        {
            try
            {
                var request = new HttpRequestMessage(HttpMethod.Get, "http://172.22.66.71/ISAPI/Security/token?format=json");
                var response = await httpClient.SendAsync(request);
                response.EnsureSuccessStatusCode();

                string jsonString = await response.Content.ReadAsStringAsync();
                var serializer = new JavaScriptSerializer();
                var tokenObj = serializer.Deserialize<Dictionary<string, Dictionary<string, string>>>(jsonString);

                return tokenObj["Token"]["value"];
            }
            catch (Exception ex)
            {
                LogMessage($"❌ Token retrieval failed: {ex.Message}");
                return null;
            }
        }

        private async Task ConnectWebSocketAsync(CancellationToken token)
        {
            try
            {
                webSocket?.Dispose();
                webSocket = new ClientWebSocket();
                await webSocket.ConnectAsync(wsUri, token);

                await SendSubscriptionMessageAsync(token);
                _ = ReceiveMessagesAsync(token); // fire and forget
            }
            catch (Exception ex)
            {
                LogMessage($"❌ WebSocket connection failed: {ex.Message}");
            }
        }

        private async Task SendSubscriptionMessageAsync(CancellationToken token)
        {
            const string subscribeXml =
               @"<WSM_Request>
                    <id>98FCE48B-09F1-44EB-B171-CFD8457504AA</id>
                    <URI>POST /ISAPI/Event/notification/subscribeEvent</URI>
                    <body>
                        <SubscribeEvent version='2.0' xmlns='http://www.isapi.org/ver20/XMLSchema'>
                            <eventMode>list</eventMode>
                            <EventList>
                                <Event><type>ANPR</type></Event>
                            </EventList>
                        </SubscribeEvent>
                    </body>
                </WSM_Request>";

            ArraySegment<byte> subscribeBytes = new ArraySegment<byte>(Encoding.UTF8.GetBytes(subscribeXml));
            await webSocket.SendAsync(subscribeBytes, WebSocketMessageType.Text, true, token);
        }

        private async Task ReceiveMessagesAsync(CancellationToken token)
        {
            var buffer = new ArraySegment<byte>(new byte[8192]);
            var stream = new MemoryStream();

            while (!token.IsCancellationRequested)
            {
                try
                {
                    WebSocketReceiveResult result;
                    do
                    {
                        if (webSocket.State != WebSocketState.Open)
                        {
                            LogMessage($"⚠️ WebSocket is not open (State: {webSocket.State}). Attempting reconnect...");
                            await HandleWebSocketRecoveryAsync(token);
                            return;
                        }

                        result = await webSocket.ReceiveAsync(buffer, token);

                        if (result.MessageType == WebSocketMessageType.Close)
                        {
                            LogMessage("ℹ️ WebSocket closed by server.");
                            await HandleWebSocketRecoveryAsync(token);
                            return;
                        }

                        stream.Write(buffer.Array, buffer.Offset, result.Count);
                    }
                    while (!result.EndOfMessage);

                    string message = Encoding.UTF8.GetString(stream.ToArray());
                    stream.SetLength(0);

                    await HandleMessageAsync(message);
                }
                catch (WebSocketException wsEx)
                {
                    LogMessage($"❌ WebSocketException: {wsEx.Message} (State: {webSocket.State})");
                    await HandleWebSocketRecoveryAsync(token);
                    return;
                }
                catch (Exception ex)
                {
                    LogMessage($"❌ General receive error: {ex.Message}");
                    await Task.Delay(2000, token);
                }
            }
        }

        private async Task HandleWebSocketRecoveryAsync(CancellationToken token)
        {
            try
            {
                webSocket?.Abort();
                webSocket?.Dispose();
            }
            catch { /* ignore */ }

            LogMessage("🔄 Reconnecting WebSocket...");
            await Task.Delay(3000, token); // cooldown πριν retry
            await InitializeAndConnectAsync(token);
        }


        private async Task HandleMessageAsync(string message)
        {
            try
            {
                var doc = XDocument.Parse(message);
                XNamespace ns = "http://www.hikvision.com/ver20/XMLSchema";

                string eventType = doc.Descendants(ns + "eventType").FirstOrDefault()?.Value;
                if (eventType != "ANPR") return;

                string licensePlate = doc.Descendants(ns + "licensePlate").FirstOrDefault()?.Value;
                string dateTime = doc.Descendants(ns + "dateTime").FirstOrDefault()?.Value;
                string direction = doc.Descendants(ns + "direction").FirstOrDefault()?.Value;
                // string id = doc.Descendants(ns + "pId").FirstOrDefault()?.Value;
             


                if (!string.IsNullOrEmpty(licensePlate) && DateTime.TryParse(dateTime, out DateTime parsedDate))
                {

                    string dateTimeCleaned = parsedDate.ToUniversalTime().ToString("yyyyMMddTHHmmssZ");
                    string id = dateTimeCleaned + "-" + licensePlate;


                    LogMessage("📸 ANPR EVENT");
                    LogMessage($"Plate: {licensePlate}, DateTime: {dateTimeCleaned}, Dir: {direction}, ID: {id}");

                    PlatesPoster poster = new PlatesPoster(httpClient);
                    await poster.PostPlatesAsyncToS1(new List<(string, string, string, string)>
                    {
                        (dateTimeCleaned, licensePlate, id, direction)
                    });
                }
            }
            catch (Exception ex)
            {
               LogMessage($"❌ Message handling error: {ex.Message}");
            }
        }

        private void LogMessage(string message)
        {
/*            try
            {
                string fullMessage = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}";

                if (!EventLog.SourceExists("HikVisionService"))
                    EventLog.CreateEventSource("HikVisionService", "Application");

                EventLog.WriteEntry("HikVisionService", fullMessage, EventLogEntryType.Information);
            }
            catch
            {
                // Fallback to file log
                Directory.CreateDirectory(Path.GetDirectoryName(logPath));
                File.AppendAllText(logPath, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} - {message}{Environment.NewLine}");
            }*/
        }
    }
}
