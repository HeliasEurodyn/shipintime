﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HikVisionIntegrationService
{
    internal class PlatesPoster
    {
        private readonly HttpClient httpClient;

        public PlatesPoster(HttpClient httpClient)
        {
            this.httpClient = httpClient;
        }

        public async Task PostPlatesAsyncToSit(List<(string StartTime, string Plate)> plates)
        {
            // Manually construct the JSON array
            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.Append("[");

            for (int i = 0; i < plates.Count; i++)
            {
                var plate = plates[i];
                jsonBuilder.Append("{")
                    .Append($"\"tracktime\":\"{plate.StartTime}\",")
                    .Append($"\"plate\":\"{plate.Plate}\"")
                    .Append("}");

                if (i < plates.Count - 1)
                {
                    jsonBuilder.Append(",");
                }
            }

            jsonBuilder.Append("]");

            string jsonPayload = jsonBuilder.ToString();

            // Prepare the content for the POST request
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            try
            {
                // Send the POST request
               // HttpResponseMessage response = await httpClient.PostAsync("http://localhost:8089/shiping-order/check-in/by-camera-tracks", content);
                HttpResponseMessage response = await httpClient.PostAsync("https://shipintime.gr/api/shiping-order/check-in/by-camera-tracks", content);

                // Read and print the response content
                string responseContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"POST Response: {responseContent}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during POST: {ex.Message}");
            }
        }

        public async Task PostPlatesAsyncToS1(List<(string StartTime, string Plate, string Id)> plates)
        {
            // Manually construct the JSON array
            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.Append("[");

            for (int i = 0; i < plates.Count; i++)
            {
                var plate = plates[i];
                jsonBuilder.Append("{")
                    .Append($"\"tracktime\":\"{plate.StartTime}\",")
                    .Append($"\"plate\":\"{plate.Plate}\",")
                    .Append($"\"id\":\"{plate.Id}\"")
                    .Append("}");

                if (i < plates.Count - 1)
                {
                    jsonBuilder.Append(",");
                }
            }

            jsonBuilder.Append("]");

            string jsonPayload = jsonBuilder.ToString();

            // Prepare the content for the POST request
            var content = new StringContent(jsonPayload, Encoding.UTF8, "application/json");

            try
            {
                // Send the POST request
                HttpResponseMessage response = await httpClient.PostAsync("https://agrohellas.oncloud.gr/s1services/JS/shipInTime.ShipInTimeContoller/syncplates", content);

                // Read and print the response content
                string responseContent = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"POST Response: {responseContent}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during POST: {ex.Message}");
            }
        }

    }
}
