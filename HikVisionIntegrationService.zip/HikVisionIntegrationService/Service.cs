﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Xml.Linq;

namespace HikVisionIntegrationService
{
    public partial class Service : ServiceBase
    {
        private Timer timer;
        private readonly HttpClient httpClient = new HttpClient();

        public Service()
        {
            InitializeComponent();

            // Δημιουργία του HttpClientHandler με Digest Authentication
            var handler = new HttpClientHandler();
            var credentials = new NetworkCredential("admin", "Odesus1977#");

            // Χρησιμοποιούμε CredentialCache ώστε να ορίσουμε ότι το συγκεκριμένο URI χρησιμοποιεί Digest
            var credentialCache = new CredentialCache();
            credentialCache.Add(new Uri("http://172.22.66.71/ISAPI/ContentMgmt/search"), "Digest", credentials);

            handler.Credentials = credentialCache;
            httpClient = new HttpClient(handler);

        }

        protected override void OnStart(string[] args)
        {
            this.Timer_Elapsed(null, null);
            timer = new Timer(30000);
            timer.Elapsed += Timer_Elapsed;
            timer.AutoReset = true;
            timer.Enabled = true;
            timer.Start();
        }

        protected override void OnStop()
        {
        }


        private async void Timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            try
            {
                // Υπολογισμός του τρέχοντος χρόνου σε UTC
                DateTime endTime = DateTime.UtcNow;
                DateTime startTime = DateTime.UtcNow.AddMinutes(-40);
                // DateTime startTime = DateTime.UtcNow.AddDays(-2);
                // Μορφοποίηση των τιμών σε ISO 8601 (π.χ. 2023-02-22T12:34:56Z)
                string formattedStartTime = startTime.ToString("yyyy-MM-ddTHH:mm:ssZ");
                string formattedEndTime = endTime.ToString("yyyy-MM-ddTHH:mm:ssZ");

                // Δημιουργία του XML σώματος με τις δυναμικές τιμές
                string xmlBody = $@"<?xml version='1.0' encoding='utf-8'?>
                                    <CMSearchDescription>
                                        <searchID>ANY_STRING_HERE</searchID>
                                        <trackIDList>
                                            <trackID>103</trackID>
                                        </trackIDList>
                                        <timeSpanList>
                                            <timeSpan>
                                                <startTime>{formattedStartTime}</startTime>
                                                <endTime>{formattedEndTime}</endTime>
                                            </timeSpan>
                                        </timeSpanList>
                                        <contentTypeList>
                                            <contentType>metadata</contentType>
                                        </contentTypeList>
                                        <maxResults>1000</maxResults>
                                        <searchResultPostion>0</searchResultPostion>
                                        <metadataList>
                                            <metadataDescriptor>//recordType.meta.std-cgi.com/vehicleDetection</metadataDescriptor>
                                            <SearchProperity>
                                                <plateSearchMask/>
                                                <nation>255</nation>
                                            </SearchProperity>
                                        </metadataList>
                                    </CMSearchDescription>";

                // Προετοιμασία της αίτησης POST με το κατάλληλο content type
                StringContent content = new StringContent(xmlBody, Encoding.UTF8, "application/xml");

                // Αποστολή της POST αίτησης
                HttpResponseMessage response = await httpClient.PostAsync("http://172.22.66.71/ISAPI/ContentMgmt/search", content);

                string responseContent = await response.Content.ReadAsStringAsync();

                List<(string StartTime, string Plate, string Id)> plates = ExtractPlaybackUriNames(responseContent);

                plates.ForEach(x => Console.WriteLine(x));

                PlatesPoster poster = new PlatesPoster(httpClient);

                 await poster.PostPlatesAsyncToS1(plates);
                // await poster.PostPlatesAsyncToSit(plates);

                Console.WriteLine(plates);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                // Χειρισμός εξαιρέσεων - μπορείς να καταγράψεις το σφάλμα στο Event Log
            }
        }

        public void DebugRun(string[] args)
        {
            this.OnStart(args);
        }

        public void DebugStop()
        {
            this.OnStop();
        }

        /*        public List<(string StartTime, string Plate, string id)> ExtractPlaybackUriNames(string xmlResponse)
                {
                    // Parse the XML document
                    XDocument doc = XDocument.Parse(xmlResponse);

                    // Define the XML namespace as declared in the response
                    XNamespace ns = "http://www.hikvision.com/ver20/XMLSchema";

                    // Create a list to hold the extracted names
                    // HashSet<string> distinctNames = new HashSet<string>();

                   // List<(string StartTime, string Plate)> extractedData = new HashSet<(string, string)>();
                    var extractedData = new List<(string StartTime, string Plate, string Name)>();

                    // Iterate over each searchMatchItem element
                    foreach (var item in doc.Descendants(ns + "searchMatchItem"))
                    {
                        // Locate the playbackURI element under mediaSegmentDescriptor
                        var playbackUriElement = item
                            .Element(ns + "mediaSegmentDescriptor")?
                            .Element(ns + "playbackURI");

                        if (playbackUriElement != null)
                        {
                            string playbackUri = playbackUriElement.Value;

                            try
                            {
                                // Create a Uri instance from the playbackURI
                                Uri uri = new Uri(playbackUri);

                                // Manual parsing of the query string
                                string query = uri.Query.TrimStart('?');
                                Dictionary<string, string> queryParameters = query
                                    .Split('&')
                                    .Select(part => part.Split('='))
                                    .Where(parts => parts.Length == 2)
                                    .ToDictionary(parts => Uri.UnescapeDataString(parts[0]), parts => Uri.UnescapeDataString(parts[1]));

                                // Extract relevant parameters
                                queryParameters.TryGetValue("starttime", out string starttime);
                                queryParameters.TryGetValue("name", out string name);

                                string plate = string.Empty;
                                if (!string.IsNullOrEmpty(name))
                                {
                                    string[] parts = name.Split('_');
                                    plate = parts.LastOrDefault(); // Assuming plate is the last part
                                }

                                if (!string.IsNullOrEmpty(starttime) && !string.IsNullOrEmpty(plate))
                                {
                                    extractedData.Add((starttime, plate, name));
                                }
                            }
                            catch (Exception ex)
                            {
                                // Handle any exceptions that might occur when parsing the URI
                                Console.WriteLine($"Error parsing URI '{playbackUri}': {ex.Message}");
                            }
                        }
                    }

                    return extractedData.ToList();
                }*/

        public List<(string StartTime, string Plate, string Id)> ExtractPlaybackUriNames(string xmlResponse)
        {
            XDocument doc = XDocument.Parse(xmlResponse);
            XNamespace ns = "http://www.hikvision.com/ver20/XMLSchema";

            var rawData = new List<(DateTime StartTime, string Plate, string Name, string StartTimeRaw)>();

            foreach (var item in doc.Descendants(ns + "searchMatchItem"))
            {
                var playbackUriElement = item
                    .Element(ns + "mediaSegmentDescriptor")?
                    .Element(ns + "playbackURI");

                if (playbackUriElement != null)
                {
                    string playbackUri = playbackUriElement.Value;

                    try
                    {
                        Uri uri = new Uri(playbackUri);
                        string query = uri.Query.TrimStart('?');

                        var queryParameters = query
                            .Split('&')
                            .Select(part => part.Split('='))
                            .Where(parts => parts.Length == 2)
                            .ToDictionary(
                                parts => Uri.UnescapeDataString(parts[0]),
                                parts => Uri.UnescapeDataString(parts[1])
                            );

                        queryParameters.TryGetValue("starttime", out string starttimeRaw);
                        queryParameters.TryGetValue("name", out string name);

                        if (!string.IsNullOrEmpty(starttimeRaw) && !string.IsNullOrEmpty(name))
                        {
                            string plate = name.Split('_').LastOrDefault();

                            if (!string.IsNullOrEmpty(plate) &&
                                DateTime.TryParseExact(starttimeRaw, "yyyyMMdd\\THHmmss\\Z", null,
                                    System.Globalization.DateTimeStyles.AssumeUniversal, out var starttime))
                            {
                                rawData.Add((starttime, plate, name, starttimeRaw));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error parsing URI '{playbackUri}': {ex.Message}");
                    }
                }
            }

            // Filter out plate entries that are within 20 seconds of each other
            var filtered = new List<(string StartTime, string Plate, string Name)>();

            var groupedByPlate = rawData
                .GroupBy(item => item.Plate);

            foreach (var group in groupedByPlate)
            {
                DateTime? lastAccepted = null;

                foreach (var item in group.OrderBy(x => x.StartTime))
                {
                    if (lastAccepted == null || (item.StartTime - lastAccepted.Value).TotalSeconds > 20)
                    {
                        filtered.Add((item.StartTimeRaw, item.Plate, item.Name));
                        lastAccepted = item.StartTime;
                    }
                }
            }

            return filtered;
        }


    }
}